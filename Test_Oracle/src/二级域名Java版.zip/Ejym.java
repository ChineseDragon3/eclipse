import java.sql.Date;


public class Ejym {

    String ejym_ID ;// 申请人工号

	public String getEjym_ID() {
		return ejym_ID;
	}
	public void setEjym_ID(String ejym_ID) {
		this.ejym_ID = ejym_ID;
	}
	public String getEjym_SQR_XM() {
		return ejym_SQR_XM;
	}
	public void setEjym_SQR_XM(String ejym_SQR_XM) {
		this.ejym_SQR_XM = ejym_SQR_XM;
	}
	public String getEjym_SQR_SJ() {
		return ejym_SQR_SJ;
	}
	public void setEjym_SQR_SJ(String ejym_SQR_SJ) {
		this.ejym_SQR_SJ = ejym_SQR_SJ;
	}
	public String getEjym_SQR_EMAIL() {
		return ejym_SQR_EMAIL;
	}
	public void setEjym_SQR_EMAIL(String ejym_SQR_EMAIL) {
		this.ejym_SQR_EMAIL = ejym_SQR_EMAIL;
	}
	public String getEjym_DWMC() {
		return ejym_DWMC;
	}
	public void setEjym_DWMC(String ejym_DWMC) {
		this.ejym_DWMC = ejym_DWMC;
	}
	public String getEjym_DWFZR() {
		return ejym_DWFZR;
	}
	public void setEjym_DWFZR(String ejym_DWFZR) {
		this.ejym_DWFZR = ejym_DWFZR;
	}
	public String getEjym_BMLB() {
		return ejym_BMLB;
	}
	public void setEjym_BMLB(String ejym_BMLB) {
		this.ejym_BMLB = ejym_BMLB;
	}
	public String getEjym_BMLB_QT() {
		return ejym_BMLB_QT;
	}
	public void setEjym_BMLB_QT(String ejym_BMLB_QT) {
		this.ejym_BMLB_QT = ejym_BMLB_QT;
	}
	public String getEjym_XZFZR_XM() {
		return ejym_XZFZR_XM;
	}
	public void setEjym_XZFZR_XM(String ejym_XZFZR_XM) {
		this.ejym_XZFZR_XM = ejym_XZFZR_XM;
	}
	public String getEjym_XZFZR_DH() {
		return ejym_XZFZR_DH;
	}
	public void setEjym_XZFZR_DH(String ejym_XZFZR_DH) {
		this.ejym_XZFZR_DH = ejym_XZFZR_DH;
	}
	public String getEjym_XZFZR_SJ() {
		return ejym_XZFZR_SJ;
	}
	public void setEjym_XZFZR_SJ(String ejym_XZFZR_SJ) {
		this.ejym_XZFZR_SJ = ejym_XZFZR_SJ;
	}
	public String getEjym_XZFZR_EMAIL() {
		return ejym_XZFZR_EMAIL;
	}
	public void setEjym_XZFZR_EMAIL(String ejym_XZFZR_EMAIL) {
		this.ejym_XZFZR_EMAIL = ejym_XZFZR_EMAIL;
	}
	public String getEjym_XTGLY_XM() {
		return ejym_XTGLY_XM;
	}
	public void setEjym_XTGLY_XM(String ejym_XTGLY_XM) {
		this.ejym_XTGLY_XM = ejym_XTGLY_XM;
	}
	public String getEjym_XTGLY_DH() {
		return ejym_XTGLY_DH;
	}
	public void setEjym_XTGLY_DH(String ejym_XTGLY_DH) {
		this.ejym_XTGLY_DH = ejym_XTGLY_DH;
	}
	public String getEjym_XTGLY_SJ() {
		return ejym_XTGLY_SJ;
	}
	public void setEjym_XTGLY_SJ(String ejym_XTGLY_SJ) {
		this.ejym_XTGLY_SJ = ejym_XTGLY_SJ;
	}
	public String getEjym_XTGLY_EMAIL() {
		return ejym_XTGLY_EMAIL;
	}
	public void setEjym_XTGLY_EMAIL(String ejym_XTGLY_EMAIL) {
		this.ejym_XTGLY_EMAIL = ejym_XTGLY_EMAIL;
	}
	public String getEjym_EJYM() {
		return ejym_EJYM;
	}
	public void setEjym_EJYM(String ejym_EJYM) {
		this.ejym_EJYM = ejym_EJYM;
	}
	public String getEjym_IP() {
		return ejym_IP;
	}
	public void setEjym_IP(String ejym_IP) {
		this.ejym_IP = ejym_IP;
	}
	public String getEjym_isOut() {
		return ejym_isOut;
	}
	public void setEjym_isOut(String ejym_isOut) {
		this.ejym_isOut = ejym_isOut;
	}
	public String getEjym_FWZL() {
		return ejym_FWZL;
	}
	public void setEjym_FWZL(String ejym_FWZL) {
		this.ejym_FWZL = ejym_FWZL;
	}
	public String getEjym_FWZL_QT() {
		return ejym_FWZL_QT;
	}
	public void setEjym_FWZL_QT(String ejym_FWZL_QT) {
		this.ejym_FWZL_QT = ejym_FWZL_QT;
	}
	public String getEjym_ZYNR() {
		return ejym_ZYNR;
	}
	public void setEjym_ZYNR(String ejym_ZYNR) {
		this.ejym_ZYNR = ejym_ZYNR;
	}
	public String getEjym_GXSH() {
		return ejym_GXSH;
	}
	public void setEjym_GXSH(String ejym_GXSH) {
		this.ejym_GXSH = ejym_GXSH;
	}
	String ejym_SQR_XM ;// 申请人姓名

	String ejym_SQR_SJ;// 申请人手机

	String ejym_SQR_EMAIL;// 申请人Email

	String ejym_DWMC;// 单位名称

	String ejym_DWFZR;// 单位负责人

	String ejym_BMLB;// 部门类别

	String ejym_BMLB_QT;// 其他部门类别说明

	String ejym_XZFZR_XM;// 行政负责人姓名

	String ejym_XZFZR_DH;// 行政负责人电话

	String ejym_XZFZR_SJ;// 行政负责人手机

	String ejym_XZFZR_EMAIL;//行政负责人Email

	String ejym_XTGLY_XM;// 系统管理员姓名

	String ejym_XTGLY_DH;// 系统管理员电话

	String ejym_XTGLY_SJ;// 系统管理员手机

	String ejym_XTGLY_EMAIL;// 系统管理员Email

	String ejym_EJYM;// 二级域名

	String ejym_IP;// 主机IP

	String ejym_isOut;// 是否需要校外访问

	String ejym_FWZL;// 服务种类

	String ejym_FWZL_QT;// 其他服务种类
	
	String ejym_ZYNR = "";// 主要内容
	String ejym_GXSH = "";// 最后更新时间
	String ejym_null;
	//Date upDate_at;

	public String getEjym_null() {
		return "";
	}

}
