import java.sql.Connection;
import java.sql.Statement;
import java.util.Iterator;
import java.util.List;


public class Test {
	public static void main(String[] args) throws Exception {
		
		//读取文件名
		String filename = "/Users/huangyue/QFL/Eclipse/Test_Oracle/src/EJYM.xlsx";
		//创建连接
		
		Connection conn = Oracal_Conn.conn();
		// 创建数据库通道
		Statement stmt = conn.createStatement();
		int while_count = 0;
		ExeclOperate excelOperate = new ExeclOperate();
		List<String> list = excelOperate.getSqlList(filename);
	        //方法1
	        Iterator<String> it1 = list.iterator();
	        while(it1.hasNext()){
	        	String insertString = it1.next();
	        	while_count++;
				System.out.println("while_count:  "+while_count+"   这里执行数据库插入语句。。。。");		
	            System.out.println(insertString);
				stmt.executeUpdate(insertString);	
	        }
		
		System.out.println("Hello End!");
	}
}
